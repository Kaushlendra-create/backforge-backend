# QuantEdge Backend — Setup Guide

## Step 1: Install Python
Download Python 3.11 from https://python.org
(Make sure to check "Add to PATH" during install)

## Step 2: Open Terminal / Command Prompt
- Windows: Press Win+R, type "cmd", press Enter
- Mac: Press Cmd+Space, type "terminal"

## Step 3: Go to project folder
```
cd path/to/quantedge
```

## Step 4: Install all packages (one time only)
```
pip install -r requirements.txt
```

## Step 5: Start the server
```
python main.py
```

You should see:
  INFO:     Uvicorn running on http://0.0.0.0:8000

## Step 6: Test it works
Open browser and go to:
  http://localhost:8000
  http://localhost:8000/docs   ← Full interactive API docs

---

## API Endpoints

### Run Backtest
POST http://localhost:8000/api/backtest

```json
{
  "strategy_text": "Buy when RSI below 30 and price above 200 MA. Sell when RSI above 70.",
  "symbol": "RELIANCE.NS",
  "market": "indian",
  "timeframe": "1d",
  "period": "5y",
  "initial_capital": 100000
}
```

### Apply Quant Model
POST http://localhost:8000/api/quant-model

```json
{
  "symbol": "BTC-USD",
  "market": "crypto",
  "model_name": "momentum",
  "period": "3y"
}
```
Model options: momentum | hmm | zscore | cvar

### Get Symbols List
GET http://localhost:8000/api/symbols

---

## Symbol Reference

| Market      | Example Symbols                          |
|-------------|------------------------------------------|
| Indian NSE  | RELIANCE.NS, TCS.NS, NIFTY50=F          |
| Crypto      | BTC-USD, ETH-USD, SOL-USD               |
| US Stocks   | AAPL, TSLA, MSFT, SPY                   |
| Forex       | EURUSD=X, USDINR=X, GBPUSD=X           |

---

## Connect to your Website
In your quantedge_platform.html, change the API URL:
  const API = "http://localhost:8000"

When you deploy to cloud later, change to your Railway/Render URL.
