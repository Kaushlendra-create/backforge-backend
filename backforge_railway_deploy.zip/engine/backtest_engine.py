import pandas as pd
import numpy as np
from typing import Dict, Any

def run_backtest(df: pd.DataFrame, signals: pd.DataFrame, initial_capital: float) -> Dict[str, Any]:
    """
    Event-driven backtest engine with stop-loss, take-profit, and full metrics.
    """
    capital    = initial_capital
    position   = 0          # shares held
    entry_price = 0.0
    trades     = []
    equity_curve = []

    sl_pct = signals['stop_loss_pct'].iloc[0]
    tp_pct = signals['take_profit_pct'].iloc[0]

    for i in range(1, len(signals)):
        row     = signals.iloc[i]
        price   = row['Close']
        signal  = row['signal']
        date    = signals.index[i]

        portfolio_val = capital + position * price
        equity_curve.append({'date': str(date.date()), 'value': round(portfolio_val, 2)})

        # ── Check stop loss / take profit if in position ─────────
        if position > 0:
            pnl_pct = (price - entry_price) / entry_price
            if pnl_pct <= -sl_pct:
                # Stop loss hit
                proceeds = position * price
                pnl      = proceeds - position * entry_price
                trades.append({
                    'type': 'SELL', 'reason': 'stop_loss',
                    'date': str(date.date()), 'price': round(price, 4),
                    'pnl': round(pnl, 2), 'pnl_pct': round(pnl_pct*100, 2)
                })
                capital += proceeds
                position = 0
                continue

            if pnl_pct >= tp_pct:
                # Take profit hit
                proceeds = position * price
                pnl      = proceeds - position * entry_price
                trades.append({
                    'type': 'SELL', 'reason': 'take_profit',
                    'date': str(date.date()), 'price': round(price, 4),
                    'pnl': round(pnl, 2), 'pnl_pct': round(pnl_pct*100, 2)
                })
                capital += proceeds
                position = 0
                continue

        # ── Buy signal ───────────────────────────────────────────
        if signal == 1 and position == 0 and capital > price:
            shares      = int(capital * 0.95 / price)
            cost        = shares * price
            capital    -= cost
            position    = shares
            entry_price = price
            trades.append({
                'type': 'BUY', 'reason': 'signal',
                'date': str(date.date()), 'price': round(price, 4),
                'shares': shares, 'pnl': 0, 'pnl_pct': 0
            })

        # ── Sell signal ──────────────────────────────────────────
        elif signal == -1 and position > 0:
            proceeds = position * price
            pnl      = proceeds - position * entry_price
            pnl_pct  = pnl / (position * entry_price)
            trades.append({
                'type': 'SELL', 'reason': 'signal',
                'date': str(date.date()), 'price': round(price, 4),
                'pnl': round(pnl, 2), 'pnl_pct': round(pnl_pct*100, 2)
            })
            capital += proceeds
            position = 0

    # Close any open position at end
    if position > 0:
        last_price = signals['Close'].iloc[-1]
        proceeds   = position * last_price
        pnl        = proceeds - position * entry_price
        trades.append({
            'type': 'SELL', 'reason': 'end_of_period',
            'date': str(signals.index[-1].date()),
            'price': round(last_price, 4),
            'pnl': round(pnl, 2),
            'pnl_pct': round((pnl / (position * entry_price))*100, 2)
        })
        capital += proceeds

    final_value = capital

    # ── Compute metrics ──────────────────────────────────────────
    sell_trades  = [t for t in trades if t['type'] == 'SELL']
    total_trades = len(sell_trades)
    winning      = [t for t in sell_trades if t['pnl'] > 0]
    losing       = [t for t in sell_trades if t['pnl'] <= 0]

    win_rate     = (len(winning) / total_trades * 100) if total_trades > 0 else 0
    total_return = ((final_value - initial_capital) / initial_capital) * 100

    gross_profit = sum(t['pnl'] for t in winning) if winning else 0
    gross_loss   = abs(sum(t['pnl'] for t in losing)) if losing else 1
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else gross_profit

    avg_win  = gross_profit / len(winning)  if winning else 0
    avg_loss = gross_loss   / len(losing)   if losing  else 0
    rr_ratio = avg_win / avg_loss if avg_loss > 0 else 0

    # Sharpe ratio (annualized)
    equity_vals = [e['value'] for e in equity_curve]
    if len(equity_vals) > 2:
        returns = pd.Series(equity_vals).pct_change().dropna()
        sharpe  = (returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0
    else:
        sharpe = 0

    # Max drawdown
    eq_series  = pd.Series(equity_vals)
    roll_max   = eq_series.cummax()
    drawdown   = (eq_series - roll_max) / roll_max * 100
    max_dd     = drawdown.min()

    # Calmar ratio
    calmar = (total_return / abs(max_dd)) if max_dd != 0 else 0

    # Monthly returns
    eq_df = pd.DataFrame(equity_curve)
    eq_df['date'] = pd.to_datetime(eq_df['date'])
    eq_df.set_index('date', inplace=True)
    monthly = eq_df['value'].resample('ME').last().pct_change().dropna() * 100
    monthly_returns = [{'month': str(m.date()), 'return': round(v, 2)}
                       for m, v in monthly.items()]

    return {
        "summary": {
            "total_return":    round(total_return, 2),
            "sharpe_ratio":    round(sharpe, 2),
            "max_drawdown":    round(max_dd, 2),
            "win_rate":        round(win_rate, 2),
            "total_trades":    total_trades,
            "profit_factor":   round(profit_factor, 2),
            "avg_win":         round(avg_win, 2),
            "avg_loss":        round(avg_loss, 2),
            "risk_reward":     round(rr_ratio, 2),
            "calmar_ratio":    round(calmar, 2),
            "initial_capital": initial_capital,
            "final_value":     round(final_value, 2),
        },
        "equity_curve":    equity_curve[-200:],   # last 200 points for chart
        "trades":          trades[-50:],           # last 50 trades
        "monthly_returns": monthly_returns[-24:],  # last 24 months
    }
