import yfinance as yf
import pandas as pd

# ── Symbol normalizer ────────────────────────────────────────────
MARKET_SUFFIX = {
    "indian": "",   # already has .NS / =F suffix
    "crypto": "",   # already has -USD suffix
    "us":     "",
    "forex":  "",
}

def fetch_ohlcv(symbol: str, market: str, timeframe: str, period: str) -> pd.DataFrame:
    """
    Fetch OHLCV data for any market using yfinance.
    Returns a clean DataFrame with columns: Open High Low Close Volume
    """
    # Map period string → yfinance period
    period_map = {"1y": "1y", "3y": "3y", "5y": "5y", "10y": "10y"}
    yf_period = period_map.get(period, "5y")

    # Map timeframe string → yfinance interval
    tf_map = {"1d": "1d", "1h": "1h", "4h": "1h", "1wk": "1wk"}
    yf_interval = tf_map.get(timeframe, "1d")

    # yfinance only supports hourly for max 730 days
    if yf_interval == "1h" and yf_period in ("5y", "10y"):
        yf_period = "2y"

    ticker = yf.Ticker(symbol)
    df = ticker.history(period=yf_period, interval=yf_interval)

    if df.empty:
        raise ValueError(f"No data found for symbol '{symbol}'. "
                         f"Check symbol name (e.g. RELIANCE.NS, BTC-USD, EURUSD=X).")

    # Clean up
    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df.dropna(inplace=True)
    df.index = pd.to_datetime(df.index)
    df.index = df.index.tz_localize(None)  # remove timezone for clean JSON

    return df
