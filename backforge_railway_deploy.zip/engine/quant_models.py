import pandas as pd
import numpy as np
from typing import Dict, Any

# ── 1. Momentum Factor Model ─────────────────────────────────────
def momentum_model(df: pd.DataFrame) -> Dict[str, Any]:
    close = df['Close']
    ret_1m  = close.pct_change(21).iloc[-1]  * 100
    ret_3m  = close.pct_change(63).iloc[-1]  * 100
    ret_6m  = close.pct_change(126).iloc[-1] * 100
    ret_12m = close.pct_change(252).iloc[-1] * 100

    score = (ret_1m * 0.1 + ret_3m * 0.2 + ret_6m * 0.3 + ret_12m * 0.4)
    if score > 15:   signal, label = "STRONG BUY",  "Strong upward momentum"
    elif score > 5:  signal, label = "BUY",         "Positive momentum"
    elif score > -5: signal, label = "NEUTRAL",     "Weak/mixed momentum"
    elif score > -15:signal, label = "SELL",        "Negative momentum"
    else:            signal, label = "STRONG SELL", "Strong downward momentum"

    return {
        "model": "Momentum Factor",
        "signal": signal, "label": label,
        "score":  round(score, 2),
        "details": {
            "1_month_return":  round(ret_1m,  2),
            "3_month_return":  round(ret_3m,  2),
            "6_month_return":  round(ret_6m,  2),
            "12_month_return": round(ret_12m, 2),
        }
    }

# ── 2. Hidden Markov / Regime Detection ─────────────────────────
def hmm_regime_model(df: pd.DataFrame) -> Dict[str, Any]:
    returns  = df['Close'].pct_change().dropna()
    vol      = returns.rolling(20).std() * np.sqrt(252)
    ret_20   = returns.rolling(20).mean() * 252

    last_vol = vol.iloc[-1]
    last_ret = ret_20.iloc[-1]
    last_close = df['Close'].iloc[-1]
    ma50  = df['Close'].rolling(50).mean().iloc[-1]
    ma200 = df['Close'].rolling(200).mean().iloc[-1]

    # Simple regime classifier
    if last_ret > 0.10 and last_close > ma50 > ma200:
        regime = "BULL"; color = "green"; advice = "Full position — trend is strong"
    elif last_ret < -0.10 or (last_close < ma50 and last_close < ma200):
        regime = "BEAR"; color = "red";   advice = "Reduce position or hedge"
    else:
        regime = "SIDEWAYS"; color = "amber"; advice = "Smaller position size, use range strategy"

    # Rolling volatility percentile
    vol_pct = int((vol.rank(pct=True).iloc[-1]) * 100)

    return {
        "model":  "Regime Detection (HMM)",
        "regime": regime, "color": color, "advice": advice,
        "details": {
            "current_regime":      regime,
            "annualized_return":   round(last_ret * 100, 2),
            "annualized_vol":      round(last_vol * 100, 2),
            "vol_percentile":      vol_pct,
            "price_vs_ma50":       round((last_close / ma50 - 1) * 100, 2),
            "price_vs_ma200":      round((last_close / ma200 - 1) * 100, 2),
        }
    }

# ── 3. Z-Score Mean Reversion ────────────────────────────────────
def zscore_model(df: pd.DataFrame) -> Dict[str, Any]:
    close   = df['Close']
    window  = 20
    roll_mean = close.rolling(window).mean()
    roll_std  = close.rolling(window).std()
    zscore    = ((close - roll_mean) / roll_std).iloc[-1]

    if zscore < -2:   signal = "STRONG BUY";  label = "Extremely oversold — strong reversion expected"
    elif zscore < -1: signal = "BUY";         label = "Oversold — mean reversion likely"
    elif zscore > 2:  signal = "STRONG SELL"; label = "Extremely overbought — reversal expected"
    elif zscore > 1:  signal = "SELL";        label = "Overbought — consider reducing"
    else:             signal = "NEUTRAL";     label = "Price near fair value"

    current = close.iloc[-1]
    fair_val = roll_mean.iloc[-1]
    target   = fair_val  # mean reversion target

    return {
        "model": "Z-Score Mean Reversion",
        "signal": signal, "label": label,
        "zscore": round(zscore, 3),
        "details": {
            "current_price":   round(current, 4),
            "fair_value_ma20": round(fair_val, 4),
            "reversion_target":round(target, 4),
            "deviation_pct":   round((current - fair_val) / fair_val * 100, 2),
            "rolling_std":     round(roll_std.iloc[-1], 4),
        }
    }

# ── 4. CVaR Risk Model ───────────────────────────────────────────
def cvar_model(df: pd.DataFrame) -> Dict[str, Any]:
    returns = df['Close'].pct_change().dropna()
    conf    = 0.95
    var_95  = float(np.percentile(returns, (1 - conf) * 100))
    cvar_95 = float(returns[returns <= var_95].mean())

    # Optimal position size (Kelly-like)
    mean_ret  = returns.mean()
    std_ret   = returns.std()
    kelly     = mean_ret / (std_ret ** 2) if std_ret > 0 else 0
    pos_size  = min(max(kelly * 0.5, 0.05), 0.30)  # half-kelly, clamp 5–30%

    # Annual VaR
    annual_var  = var_95  * np.sqrt(252) * 100
    annual_cvar = cvar_95 * np.sqrt(252) * 100

    risk_level = "LOW" if abs(annual_cvar) < 15 else ("MEDIUM" if abs(annual_cvar) < 30 else "HIGH")

    return {
        "model": "CVaR Risk Optimizer",
        "risk_level": risk_level,
        "details": {
            "daily_var_95":        round(var_95  * 100, 3),
            "daily_cvar_95":       round(cvar_95 * 100, 3),
            "annualized_var":      round(annual_var,    2),
            "annualized_cvar":     round(annual_cvar,   2),
            "recommended_position":f"{round(pos_size * 100, 1)}% of portfolio",
            "kelly_fraction":      round(kelly, 4),
        },
        "advice": f"Risk level is {risk_level}. Max recommended position: {round(pos_size*100,1)}% of capital."
    }

# ── Router ───────────────────────────────────────────────────────
MODEL_MAP = {
    "momentum": momentum_model,
    "hmm":      hmm_regime_model,
    "zscore":   zscore_model,
    "cvar":     cvar_model,
}

def apply_quant_model(model_name: str, df: pd.DataFrame) -> Dict[str, Any]:
    fn = MODEL_MAP.get(model_name.lower())
    if not fn:
        raise ValueError(f"Unknown model '{model_name}'. Choose from: {list(MODEL_MAP.keys())}")
    return fn(df)
