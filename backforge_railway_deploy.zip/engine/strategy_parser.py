import pandas as pd
import numpy as np
import re

# ── Indicator calculators ────────────────────────────────────────
def calc_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0).rolling(period).mean()
    loss  = (-delta.clip(upper=0)).rolling(period).mean()
    rs    = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def calc_ma(close: pd.Series, period: int) -> pd.Series:
    return close.rolling(period).mean()

def calc_ema(close: pd.Series, period: int) -> pd.Series:
    return close.ewm(span=period, adjust=False).mean()

def calc_macd(close: pd.Series):
    fast = close.ewm(span=12, adjust=False).mean()
    slow = close.ewm(span=26, adjust=False).mean()
    macd = fast - slow
    signal = macd.ewm(span=9, adjust=False).mean()
    return macd, signal

def calc_bb(close: pd.Series, period: int = 20):
    mid  = close.rolling(period).mean()
    std  = close.rolling(period).std()
    return mid + 2*std, mid, mid - 2*std   # upper, mid, lower

def calc_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    h, l, c = df['High'], df['Low'], df['Close']
    tr = pd.concat([h-l, (h-c.shift()).abs(), (l-c.shift()).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def calc_stoch(df: pd.DataFrame, k=14, d=3):
    low_min  = df['Low'].rolling(k).min()
    high_max = df['High'].rolling(k).max()
    pct_k = 100 * (df['Close'] - low_min) / (high_max - low_min).replace(0, np.nan)
    pct_d = pct_k.rolling(d).mean()
    return pct_k, pct_d

# ── Extract number from text ─────────────────────────────────────
def extract_num(text: str, keyword: str, default: int) -> int:
    pattern = rf'{keyword}\s*[\(\[]?\s*(\d+)'
    m = re.search(pattern, text, re.IGNORECASE)
    return int(m.group(1)) if m else default

# ── Strategy parser ──────────────────────────────────────────────
def parse_strategy(text: str, df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts plain-English strategy text into buy/sell signal columns.
    Returns df with added columns: signal (1=buy, -1=sell, 0=hold),
    stop_loss_pct, take_profit_pct
    """
    t = text.lower()
    close = df['Close']

    # ── Build indicators based on what user mentioned ────────────
    indicators = {}

    if 'rsi' in t:
        p = extract_num(t, 'rsi', 14)
        indicators['rsi'] = calc_rsi(close, p)

    for kw in ['sma', 'ma', 'moving average', 'simple moving']:
        if kw in t:
            for period in [5,9,10,20,50,100,200]:
                if str(period) in t:
                    indicators[f'ma{period}'] = calc_ma(close, period)
            if not any(f'ma{p}' in indicators for p in [5,9,10,20,50,100,200]):
                indicators['ma50'] = calc_ma(close, 50)

    if 'ema' in t:
        for period in [9,12,20,26,50,200]:
            if str(period) in t:
                indicators[f'ema{period}'] = calc_ema(close, period)
        if not any(f'ema{p}' in indicators for p in [9,12,20,26,50,200]):
            indicators['ema20'] = calc_ema(close, 20)

    if 'macd' in t:
        indicators['macd'], indicators['macd_signal'] = calc_macd(close)

    if 'bollinger' in t or 'bb' in t or 'band' in t:
        indicators['bb_upper'], indicators['bb_mid'], indicators['bb_lower'] = calc_bb(close)

    if 'stoch' in t:
        indicators['stoch_k'], indicators['stoch_d'] = calc_stoch(df)

    # ── Parse stop loss & take profit ───────────────────────────
    sl_match = re.search(r'stop\s*loss[^\d]*(\d+(?:\.\d+)?)\s*%', t)
    tp_match = re.search(r'(take\s*profit|target)[^\d]*(\d+(?:\.\d+)?)\s*%', t)
    stop_loss_pct   = float(sl_match.group(1)) / 100 if sl_match else 0.02
    take_profit_pct = float(tp_match.group(2)) / 100 if tp_match else 0.06

    # ── Generate buy signals ─────────────────────────────────────
    buy_conds  = []
    sell_conds = []

    # RSI rules
    if 'rsi' in indicators:
        rsi = indicators['rsi']
        oversold  = extract_num(t, r'rsi.*?(?:below|<|under|oversold)', 30) if any(
            k in t for k in ['below','<','under','oversold']) else 30
        overbought = extract_num(t, r'rsi.*?(?:above|>|over|overbought)', 70) if any(
            k in t for k in ['above','>','over','overbought']) else 70
        buy_conds.append(rsi < oversold)
        sell_conds.append(rsi > overbought)

    # MA crossover / price above MA
    for key, ma in {k: v for k, v in indicators.items() if k.startswith('ma')}.items():
        if 'above' in t or 'cross' in t:
            buy_conds.append(close > ma)
            sell_conds.append(close < ma)
        elif 'below' in t:
            buy_conds.append(close < ma)

    # EMA rules
    if 'ema9' in indicators and 'ema20' in indicators:
        buy_conds.append(indicators['ema9'] > indicators['ema20'])
        sell_conds.append(indicators['ema9'] < indicators['ema20'])

    # MACD rules
    if 'macd' in indicators:
        buy_conds.append(indicators['macd'] > indicators['macd_signal'])
        sell_conds.append(indicators['macd'] < indicators['macd_signal'])

    # Bollinger Band rules
    if 'bb_lower' in indicators:
        buy_conds.append(close < indicators['bb_lower'])
        sell_conds.append(close > indicators['bb_upper'])

    # Stochastic rules
    if 'stoch_k' in indicators:
        buy_conds.append(indicators['stoch_k'] < 20)
        sell_conds.append(indicators['stoch_k'] > 80)

    # ── Fallback: RSI only strategy if nothing detected ─────────
    if not buy_conds:
        rsi = calc_rsi(close, 14)
        buy_conds  = [rsi < 35]
        sell_conds = [rsi > 65]

    # ── Combine conditions ───────────────────────────────────────
    buy_signal  = buy_conds[0]
    for c in buy_conds[1:]:
        buy_signal = buy_signal & c

    sell_signal  = sell_conds[0]
    for c in sell_conds[1:]:
        sell_signal = sell_signal & c

    df = df.copy()
    df['signal'] = 0
    df.loc[buy_signal,  'signal'] = 1
    df.loc[sell_signal, 'signal'] = -1
    df['stop_loss_pct']   = stop_loss_pct
    df['take_profit_pct'] = take_profit_pct

    return df
