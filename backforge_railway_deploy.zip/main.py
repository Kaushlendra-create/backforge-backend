from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uvicorn
import os

from engine.data_fetcher import fetch_ohlcv
from engine.strategy_parser import parse_strategy
from engine.backtest_engine import run_backtest
from engine.quant_models import apply_quant_model

app = FastAPI(title="Backforge API", version="2.0.0")

# CORS — allow backforge.com + netlify
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://backforge.com",
        "http://backforge.com",
        "https://backforge-app.netlify.app",
        "http://localhost:3000",
        "http://localhost:8080",
        "*"
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

class BacktestRequest(BaseModel):
    strategy_text: str
    symbol: str
    market: str
    timeframe: str
    period: str
    initial_capital: float = 100000.0

class QuantModelRequest(BaseModel):
    symbol: str
    market: str
    model_name: str
    period: str = "3y"

@app.get("/")
def root():
    return {"status": "Backforge API live", "version": "2.0.0"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/backtest")
def backtest(req: BacktestRequest):
    try:
        df      = fetch_ohlcv(req.symbol, req.market, req.timeframe, req.period)
        signals = parse_strategy(req.strategy_text, df)
        result  = run_backtest(df, signals, req.initial_capital)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/quant-model")
def quant_model(req: QuantModelRequest):
    try:
        df     = fetch_ohlcv(req.symbol, req.market, "1d", req.period)
        result = apply_quant_model(req.model_name, df)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/symbols")
def get_symbols():
    return {
        "indian":  ["RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS","NIFTY50=F"],
        "crypto":  ["BTC-USD","ETH-USD","BNB-USD","SOL-USD","XRP-USD"],
        "us":      ["AAPL","TSLA","MSFT","NVDA","AMZN","SPY","QQQ"],
        "forex":   ["EURUSD=X","GBPUSD=X","USDINR=X","USDJPY=X","GC=F"],
    }

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port)
